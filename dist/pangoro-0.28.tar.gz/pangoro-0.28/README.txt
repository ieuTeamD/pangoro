python-package-example

This is a minimal python package, for use alongside the lesson: https://github.com/ieuTeamD

Contributing:

Please do! Guidelines:

 - Max 100 lines per PR please.
 - Open an issue or empty PR first to talk about controversial changes.
